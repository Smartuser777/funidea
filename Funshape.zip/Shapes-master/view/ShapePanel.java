package view;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import controller.ShapeEventListener;

public class ShapePanel {
	public enum GameState {
		READY, PLAYING, GAMEOVER
	}

    private JFrame window;

    private JButton NewGameButton;
    private JButton exitButton;

    private ShapeCanvas canvas;

    public ShapePanel(JFrame window){
        this.window = window;
    }

    public void init(){
        Container cp = window.getContentPane();

        JPanel southPanel = new JPanel();
        cp.add(BorderLayout.SOUTH, southPanel);

        NewGameButton = new JButton("New game");
        exitButton = new JButton("Exit");
        southPanel.add(NewGameButton);
        southPanel.add(exitButton);

        canvas = new ShapeCanvas(this);
        cp.add(BorderLayout.CENTER, canvas);

        ShapeEventListener listener = new ShapeEventListener(this);
        NewGameButton.addActionListener(listener);
        exitButton.addActionListener(listener);

    }

    public JButton getExitButton(){
        return exitButton;
    }

    public JButton getRandomShapeButton() {
        return NewGameButton;
    }

    public ShapeCanvas getCanvas() {
        return canvas;
    }

    public JFrame getWindow() {
        return window;
    }
    
}