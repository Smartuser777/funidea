package controller;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


import javax.swing.JButton;
import javax.swing.JFrame;

import model.Rectangle;
import model.Circle;
import model.Shape;
import view.MenuScreen;
import view.ShapePanel;

public class ShapeEventListener implements ActionListener, MouseListener {

    private ShapePanel panel;
	private int status;

    public ShapeEventListener(ShapePanel panel) {
        this.panel = panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        if (button == panel.getExitButton()) {
            JFrame window = panel.getWindow();
            window.getContentPane().removeAll();
            var menu = new MenuScreen(window);
            menu.init();
            window.pack();
            window.revalidate();

        } else if (button == panel.getRandomShapeButton()) {
            ArrayList<Shape> shapes = panel.getCanvas().getShapes();
            shapes.clear();

            Random random = new Random();
                int r = random.nextInt(256);
                int g = random.nextInt(256);
                Color c = new Color (r, g, 0);
                shapes.add(new Rectangle(random.nextInt(500), random.nextInt(500), c, 25));
                shapes.add(new Circle(random.nextInt(500), random.nextInt(500), c, 25));
            panel.getCanvas().repaint();
        }
    }
	//
	@Override

    public void mouseClicked(MouseEvent e) {
		if (status == 0) {
	
				status = 1;
	
			} else if (status == 1) { // red light is "on"
				status = 2;
	
			} else if (status == 2) { // yellow light is "on"
				status = 3;
			} else if (status == 3) { // green light is "on"
	
				status = 1;
			}
        panel.getCanvas().repaint();
    }

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}
	/* MAY USE MOUSE OR KEY TO CREATE Game
	public class MyKeyAdapter extends KeyAdapter{
		@Override
		public void keyPressed(KeyEvent e) {
			switch(e.getKeyCode()) {
			case KeyEvent.VK_LEFT:
				if (direction != 'R') {
					direction = 'L';
				}
				break;
			case KeyEvent.VK_RIGHT:
				if (direction != 'L') {
					direction = 'R';
			}
			break;
			case KeyEvent.VK_UP:
				if (direction != 'D') {
					direction = 'U';
			}
			break;
			case KeyEvent.VK_DOWN:
				if (direction != 'U') {
					direction = 'D';
			}
			break;
			} */
}